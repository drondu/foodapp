package com.aplicatiesma;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MenuActivity extends AppCompatActivity {
    private String TAG = "MenuActivity: ";
    private DatabaseReference databaseReference;
    private ArrayList<MenuObject> pizzaObjs = new ArrayList<>();
    private ArrayList<MenuObject> pastaObjs = new ArrayList<>();
    private MenuAdapter pizzaAdapter, pastaAdapter;
    private ListView pizzaList, pastaList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        pizzaList = findViewById(R.id.pizzaList);
        pizzaObjs.clear();

        databaseReference = FirebaseDatabase.getInstance().getReference("menu").child("pizza");
        pizzaAdapter = new MenuAdapter(MenuActivity.this, pizzaObjs);
        pizzaList.setAdapter(pizzaAdapter);

        Log.i(TAG, "started the menu activity");
        Log.i(TAG, "filling pizza list");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                pizzaObjs.clear();
                Log.i(TAG, "onDataChange");
                for (DataSnapshot postSnapshot: snapshot.getChildren()){
                    Log.i(TAG, "for iteration " +  postSnapshot.getKey() + " " + postSnapshot.child("pret").getValue().toString());
                    MenuObject obj = new MenuObject(postSnapshot.getKey(), postSnapshot.child("pret").getValue().toString(), postSnapshot.child("descriere").getValue().toString());
                    pizzaObjs.add(obj);
                }

                pizzaAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.i(TAG, "onCancelled");
            }
        });


        databaseReference = FirebaseDatabase.getInstance().getReference("menu").child("paste");

        pastaList = findViewById(R.id.pastaList);
        pastaObjs.clear();

        Log.i(TAG, "filling pasta list");
        pastaAdapter = new MenuAdapter(MenuActivity.this, pastaObjs);
        pastaList.setAdapter(pastaAdapter);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                pastaObjs.clear();
                Log.i(TAG, "onDataChange");
                for (DataSnapshot postSnapshot: snapshot.getChildren()){
                    Log.i(TAG, "for iteration " +  postSnapshot.getKey() + " " + postSnapshot.child("pret").getValue().toString());
                    MenuObject obj = new MenuObject(postSnapshot.getKey(), postSnapshot.child("pret").getValue().toString(), postSnapshot.child("descriere").getValue().toString());
                    pastaObjs.add(obj);
                }

                pastaAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.i(TAG, "onCancelled");
            }
        });
    }
}

class MenuObject {
    private String name;
    private String price;
    private String description;

    public MenuObject() {
    }

    public MenuObject(String name, String price, String description) {
        this.name = name;
        this.price = price;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {return description;}

    public String getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return "name='" + name + "\n" +
                ", price='" + price + "\n" +
                ", description='" + description ;
    }

    public String toStringForSearch(){
        return name + ",  " + price;
    }
}

class MenuAdapter extends BaseAdapter {
    ArrayList<MenuObject> foods;
    Context context;
    LayoutInflater inflater;

    public MenuAdapter(Context context, ArrayList<MenuObject> objects) {
        // TODO Auto-generated constructor stub
        this.context = context;
        inflater = LayoutInflater.from(context);
        this.foods = objects;
    }

    @Override
    public int getCount() {
        return foods.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewGroup vg;

        if (convertView != null) {
            vg = (ViewGroup) convertView;
        } else {
            vg = (ViewGroup) inflater.inflate(R.layout.menu_object_row, null);
        }

        MenuObject mnObj = foods.get(position);

        TextView pizzaName = vg.findViewById(R.id.pizzaName);
        TextView pizzaPrice = vg.findViewById(R.id.pizzaPrice);

        pizzaName.setText(mnObj.getName());
        pizzaPrice.setText(mnObj.getPrice());

        ImageButton btn = vg.findViewById(R.id.addToCartButton);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                final String selectedItem = (String) parent.getItemAtPosition(position);
                final MenuObject objSelected = foods.get(position);
                Log.d("ION SI GINA: ", objSelected.getName());
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setMessage(objSelected.toString())
                        .setPositiveButton("Add to cart", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Log.i("ioane: ", "no n-ai traba");
                            }
                        })
                        .setNegativeButton("Close", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                // Create the AlertDialog object and return it
                AlertDialog alert = builder.create();
                alert.show();
            }
        });
        return vg;
    }
}