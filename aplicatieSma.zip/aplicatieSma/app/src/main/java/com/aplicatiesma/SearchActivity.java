package com.aplicatiesma;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class SearchActivity extends AppCompatActivity {
    private String TAG = "SearchActivity: ";
    private Button searchBtn;
    private EditText textSearched;
    private ListView pizzaFoundList;
    private ListView pastaFoundList;
    private DatabaseReference databaseReference;
    private MenuAdapter pizzaAdapter, pastaAdapter;
    private ArrayList<MenuObject> pizzaObjects, pastaObjects;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        pizzaObjects = new ArrayList<>();
        pastaObjects = new ArrayList<>();
        databaseReference = FirebaseDatabase.getInstance().getReference("menu");
        pastaFoundList = findViewById(R.id.pastaFoundList);
        pizzaFoundList = findViewById(R.id.pizzaFoundList);
        searchBtn = findViewById(R.id.searchBtn);
        textSearched = findViewById(R.id.foodSearched);

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String textSearchedValue = textSearched.getText().toString();
                Log.i(TAG, "ion bulea");
                searchForPizza(textSearchedValue);
                searchForPasta(textSearchedValue);
            }
        });
    }


    private void searchForPizza(final String searchedObj){
        DatabaseReference db = databaseReference.child("pizza");
        pizzaAdapter = new MenuAdapter(SearchActivity.this, pizzaObjects);
        pizzaFoundList.setAdapter(pizzaAdapter);
        Log.i(TAG, "catapulta");
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                pizzaObjects.clear();
                Log.i(TAG, "onDataChange");
                for (DataSnapshot postSnapshot: snapshot.getChildren()){

                    Log.i(TAG, postSnapshot.getKey());
                    if (postSnapshot.getKey().equals(searchedObj)){
                        Log.i(TAG, "herehre");
                        MenuObject obj = new MenuObject(postSnapshot.getKey(), postSnapshot.child("pret").getValue().toString(), postSnapshot.child("descriere").getValue().toString());
                        String xy = obj.toStringForSearch();
                        pizzaObjects.add(obj);
                    }
                }
                pizzaAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void searchForPasta(final String searchedObj){
        DatabaseReference db = databaseReference.child("paste");
        pastaAdapter = new MenuAdapter(SearchActivity.this, pastaObjects);
        pastaFoundList.setAdapter(pastaAdapter);
        Log.i(TAG, "caut pasat");
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Log.i(TAG, "onDataChange");
                pastaObjects.clear();
                for (DataSnapshot postSnapshot: snapshot.getChildren()){

                    Log.i(TAG, "herehre 33333");
                    if (postSnapshot.getKey().equals(searchedObj)){
                        Log.i(TAG, "herehre 222");
                        MenuObject obj = new MenuObject(postSnapshot.getKey(), postSnapshot.child("pret").getValue().toString(), postSnapshot.child("descriere").getValue().toString());
                        pastaObjects.add(obj);
                    }
                }
                pastaAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}